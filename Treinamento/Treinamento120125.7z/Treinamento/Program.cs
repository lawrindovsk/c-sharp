﻿using Data;

namespace Treinamento;

class Program
{
    static void Main(string[] args)
    {
        Menu.Treinamento();
    }
}
